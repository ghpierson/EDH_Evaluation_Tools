#Script Name:                   F1_Flowcheck_D8_and_WBDcats.py
#Corresponding Script Tool:     
#Purpose:                       
#Methodology:                                                  
#Author:                        Gardner Pierson, North Carolina State University, 03/8/2021

# Import arcpy module
import sys,os,arcpy,datetime
from arcpy import env
from arcpy.sa import *
arcpy.env.overwriteOutput=True
arcpy.CheckOutExtension('Spatial') 

# Script arguments
EDHwksp=sys.argv[1]#EDH_workspace

inputSourceDEM=sys.argv[2] 

minDepth= float(sys.argv[3])

flowAccCellsD8=float(sys.argv[4])

flowAccCellsDinf=float(sys.argv[5])

CHIP = float(sys.argv[6])

### Setting up the workspace
tempDir = os.path.join(EDHwksp, "EDH_FC_Assessment_TempDir")
EDHgdb=os.path.join(EDHwksp, "EDH_FC_Assessment_TempDir/tempFC1.gdb")
arcpy.env.workspace= EDHgdb
arcpy.AddMessage('Workspace Set')

### Analysis
# Fill the Sinks
arcpy.gp.Fill_sa(inputSourceDEM, 'Fillsmall', "")
arcpy.AddMessage('Sinks Filled')

# Map Algebra
r1=arcpy.Raster(inputSourceDEM)
r2=arcpy.Raster('Fillsmall')
outRast= r2 - r1
outRast.save('tmpcalc')
### arcpy.gp.RasterCalculator_sa("\"%Fillsmall%\" - \"%dem_sub%\"", tmpcalc)
arcpy.AddMessage('Map Algebra Complete')

# Conditional Statement
outConRast = Con('tmpcalc', 'tmpcalc', "", "VALUE >= {0}".format(minDepth))
outConRast.save('DepthHalfm')
arcpy.AddMessage('Depth Raster DepthHalfm Created')

# D-8 Flow Dir
arcpy.gp.FlowDirection_sa('Fillsmall', 'fdr', "NORMAL", "", "D8")
arcpy.AddMessage('D8 Flow Direction Raster Created')

# D-8 Flow Accumulation
arcpy.gp.FlowAccumulation_sa('fdr', 'fac', "", "INTEGER", "D8")
arcpy.AddMessage('D8 Flow Accumulation Raster Created')

# Conditional Statement
arcpy.gp.Con_sa('fac', 1, 'con_tif1', "", "Value >= {0}".format(flowAccCellsD8))

# Stream to Feature
arcpy.gp.StreamToFeature_sa('con_tif1', 'fdr', 'Output_stream_check', "NO_SIMPLIFY")
arcpy.AddMessage('Stream To Feature Complete (Output_stream_check Created)')

# Conditional Statement
arcpy.gp.Con_sa('fac', 1, 'con_tif2', "", "Value >= {0}".format(CHIP))

# Create Streams Layer via Stream Link 
arcpy.gp.StreamLink_sa('con_tif2', 'fdr', 'StreamL_con_1')
arcpy.AddMessage('Stream Link Created (StreamL_con_1 Created)')

# Create Watershed
arcpy.gp.Watershed_sa('fdr', 'StreamL_con_1', 'catchments50kAcres', "VALUE")
arcpy.AddMessage('D8 Catchment Areas Created (catchments50kAcres Created)')

# Convert Raster To Polygon
arcpy.RasterToPolygon_conversion('catchments50kAcres', 'Catchments50kAcres_shp', "NO_SIMPLIFY", "Value", "SINGLE_OUTER_PART", "")
arcpy.AddMessage('D8 Catchment Areas Converted to Polygons')

# Get D-inf Flow Dir and Flow Accumulation raster with starting Flow Acc Threshold passed in by user
arcpy.gp.FlowDirection_sa(r1, 'fdr_dinf', "FORCE", "", "DINF")
arcpy.AddMessage('DINF Flow Direction Raster Created')
arcpy.gp.FlowAccumulation_sa('fdr_dinf', 'fac_dinf', "", "FLOAT", "DINF")
arcpy.AddMessage('DINF Flow Accumulation Raster Created')
arcpy.gp.Con_sa('fac_dinf', 'fac_dinf', 'StrmDInf_area', "", "Value >= {0}".format(flowAccCellsDinf))
arcpy.AddMessage('DINF Threshold Raster Created')

# Copy Output Files to Evaluation GDB
EDHmain=os.path.join(EDHwksp, "EDH_FC_Evaluation.gdb")
fdD8=os.path.join(EDHmain, 'FC1_'+ 'fdr')
fdDinf=os.path.join(EDHmain, 'FC1_'+ 'fdr_dinf')
facD8=os.path.join(EDHmain, 'FC1_'+ 'fac')
facDinf=os.path.join(EDHmain, 'FC1_'+ 'fac_dinf')
depthRas=os.path.join(EDHwksp, 'DepthHalfm')
arcpy.management.CopyRaster('fdr',fdD8)
arcpy.management.CopyRaster('fdr_dinf',fdDinf)
arcpy.management.CopyRaster('fac',facD8)
arcpy.management.CopyRaster('fac_dinf',facDinf)
arcpy.management.CopyRaster('DepthHalfm',depthRas)
arcpy.AddMessage('Rasters copied from Temp to Main GDB')
# Copy Outputs to Workspace so External Tool can Access them
fdD8=os.path.join(EDHwksp, 'fdr.tif')
fdDinf=os.path.join(EDHwksp, 'fdr_dinf.tif')
facD8=os.path.join(EDHwksp, 'fac.tif')
facDinf=os.path.join(EDHwksp, 'fac_dinf.tif')
depthRas=os.path.join(EDHwksp, 'DepthHalfm.tif')
arcpy.management.CopyRaster('fdr',fdD8)
arcpy.management.CopyRaster('fdr_dinf',fdDinf)
arcpy.management.CopyRaster('fac',facD8)
arcpy.management.CopyRaster('fac_dinf',facDinf)
arcpy.management.CopyRaster('DepthHalfm',depthRas)
arcpy.AddMessage('Rasters copied from Temp to uutput directory and saved as TIF')

# Add Results to Report
reportWksp=os.path.join(EDHwksp, 'EDH_FC_Assessment_TempDir/Report')
with open(reportWksp+'/Report.txt','a') as fout:
    fout.write('Results for QC3 Make Density by HU12\n\n')
    now = datetime.datetime.now()
    currentTime = now.strftime("%B:%d:%Y:%H:%M:%S")
    fout.write('Report Created: {}\n'.format(currentTime))
    fout.write('{}    Created\n'.format(os.path.basename(fdD8)))
    fout.write('{}    Created\n'.format(os.path.basename(fdDinf)))
    fout.write('{}    Created\n'.format(os.path.basename(facD8)))
    fout.write('{}    Created\n'.format(os.path.basename(facDinf)))
    fout.write('{}    Created\n\n\n\n'.format(os.path.basename(depthRas)))
arcpy.AddMessage('Report Updated')
os.startfile(reportWksp+'/Report.txt')


