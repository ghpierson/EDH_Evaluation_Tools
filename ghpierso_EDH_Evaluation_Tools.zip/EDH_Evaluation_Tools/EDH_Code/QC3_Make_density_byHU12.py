#Script Name:                   Make_density_byHU12.py
#Corresponding Script Tool:     Make Density By HU12
#Purpose:                       Quanitfy the increase in stream density at the HU12 level 
#Methodology:                   Check SpatialRef -> Clip -> Add/Calc Field -> Intersect -> AddGeom->
#                               SumStat -> Add/Calc Field -> AddGeom _> Add/Calc Field -> Sum -> Add/Calc Field ->
#                               Join -> Add/Calc Field -> Join -> Copy -> Calc -> WriteReport
#Author:                        Gardner Pierson, North Carolina State University, 03/25/2021

import arcpy, sys, os, datetime

#arguements

EDHwksp=sys.argv[1]#EDH_workspace

NHD_Lines=sys.argv[2]#NHD data

DPA=sys.argv[3]#DPA

WBD_input = sys.argv[4]#Watershed Boundary Data (HU12)

#spatial_ref = sys.argv[5] #Currectly script gets this from EDH_Lines 

#Set up Workspace
arcpy.env.overwriteOutput=True
EDHgdb=os.path.join(EDHwksp, "EDH_QC_Assessment_TempDir/tempQC3.gdb")
arcpy.env.workspace= EDHgdb
EDHmain=os.path.join(EDHwksp, "EDH_QC_Evaluation.gdb")
#WBD=os.path.join(WBD_input, "EDH_Assessment_TempDir/tempQC3.gdb")
arcpy.CopyFeatures_management(WBD_input, 'WBD')
arcpy.AddMessage('Workspace Set')

#Run Spatial Reference Check to ensure input data SR matches the EDH SR
dataset = os.path.join(EDHmain, "EDH_Lines")
spatial_ref = arcpy.Describe(dataset).spatialReference
srNHD=arcpy.Describe(NHD_Lines).spatialReference
srDPA=arcpy.Describe(DPA).spatialReference
srWBD=arcpy.Describe(WBD_input).spatialReference
nhdProj=False
dbaProj=False
wbdProj=False
if spatial_ref == srNHD:
    output_feature_class=os.path.join(EDHgdb,'NHD_Lines_Proj')
    arcpy.Project_management(NHD_Lines, output_feature_class, spatial_ref)
    arcpy.AddError('NHD Projection Does Not Match EDH Projection. NHD data has been reprojected as NHD_Lines_Proj and has been\
    added to the tempQC3.gdb, Please rerun tool with this Projected Data.')
    nhdProj=True
if spatial_ref == srDPA:
    output_feature_class=os.path.join(EDHgdb,'DPA_Proj')
    arcpy.Project_management(DPA, output_feature_class, spatial_ref)
    arcpy.AddError('DPA Projection Does Not Match EDH Projection. DPA data has been reprojected as DPA_Proj and has been\
    added to the tempQC3.gdb, Please rerun tool with this Projected Data.')
    dbaProj=True
if spatial_ref == srNHD:
    output_feature_class=os.path.join(EDHgdb,'WBD_Proj')
    arcpy.Project_management(WBD_input, output_feature_class, spatial_ref)
    arcpy.AddError('WBD Projection Does Not Match EDH Projection. WBD data has been reprojected as DPA_Proj and has been\
    added to the tempQC3.gdb, Please rerun tool with this Projected Data.')
    wbdProj=True
if nhdProj == True or dbaProj==True or wbdProj==True:
    arcpy.AddMessage('Script will not run untill all projections mentioned above are matching, pleae rerun with correctly\
    projected data from tempQC3.gdb')
    sys.exit(0)
arcpy.AddMessage('Projections of EDH and Lines/Polys Match')

### Analysis
# Process: Clip
nhdClip=os.path.join(EDHgdb, "nhdflowlines_Clip")
arcpy.Clip_analysis(NHD_Lines, DPA, nhdClip, "")
arcpy.AddMessage('NHD Flowlines Clipped to Defined Project Area')

# Process: Add Field (8)
arcpy.AddField_management('nhdflowlines_Clip', "FID_NHD", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

# Process: Calculate Field (7)
arcpy.CalculateField_management('nhdflowlines_Clip', "FID_NHD", "[OBJECTID]", "VB", "")
arcpy.AddMessage('FID_NHD Field Created and Calculated')

# Process: Intersect
intersectList=['nhdflowlines_Clip', 'WBD']
intersectOut='NHDfl_wbd'
arcpy.Intersect_analysis(intersectList, intersectOut, "ALL", "", "INPUT")
arcpy.AddMessage('NHD Flowlines Intersected with Watershed Boundary Data')

# Process: Add Geometry Attributes (2)
dataset = os.path.join(EDHmain, "EDH_Lines")
arcpy.AddGeometryAttributes_management('NHDfl_wbd', "LENGTH", "METERS", "", spatial_ref)
arcpy.AddMessage('Length in Meters Added to NHDf1_wbd')

# Process: Summary Statistics
statsSum=os.path.join(EDHgdb, "NHD_StatsSum")
arcpy.Statistics_analysis('NHDfl_wbd', statsSum, "LENGTH SUM", "HUC12")
arcpy.AddMessage('Sum of Legnths of NHDf1_wbd Calculated')

# Process: Add Field (7)
arcpy.AddField_management(statsSum, "NHDlength_m", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

# Process: Calculate Field (5)
arcpy.CalculateField_management(statsSum, "NHDlength_m", "[SUM_LENGTH]", "VB", "")
arcpy.AddMessage('NHD SUM Length Field (NHDlength_m) Created and Calculated for NHD_StatsSum')

# Process: Intersect (2)
intersectList2=[dataset,'WBD']
intersectOut2='EDH_wbd12'
arcpy.Intersect_analysis(intersectList2, intersectOut2, "ALL", "", "INPUT")
arcpy.AddMessage('EDH Lines Intersected with Watershed Boundary Data')

# Process: Add Geometry Attributes
arcpy.AddGeometryAttributes_management('EDH_wbd12', "LENGTH", "Meters", "", "") 

# Process: Add Field (5)
arcpy.AddField_management('EDH_wbd12', "EDHLength", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

# Process: Calculate Field (6)
arcpy.CalculateField_management('EDH_wbd12', "EDHLength", "[LENGTH]", "VB", "")
arcpy.AddMessage('EDH Length Geometry added, Field EDHLenght Created and Calculated')

# Process: Summary Statistics (2)
statsSum2 = os.path.join(EDHgdb, "EDHLength_SUM")
arcpy.Statistics_analysis('EDH_wbd12', statsSum2, "EDHLength SUM", "HUC12")
arcpy.AddMessage('Sum of EDHLength Calculated')

# Process: Join Field (2)
arcpy.JoinField_management(statsSum, "HUC12", statsSum2, "HUC12", "HUC12;FREQUENCY;SUM_EDHLength")

# Process: Add Field (4)
arcpy.AddField_management(statsSum, "DensIncr", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

# Process: Calculate Field (2)
arcpy.CalculateField_management(statsSum, "DensIncr", "[SUM_EDHLength] / [NHDlength_m]", "VB", "")

# Process: Join Field (3)
arcpy.JoinField_management('WBD', "HUC12", statsSum, "HUC12", "FREQUENCY;SUM_LENGTH;NHDlength_m;FREQUENCY_1;SUM_EDHLength;DensIncr")
arcpy.AddMessage('All Fields Correctly Joined and Calculated')

# Copy Output Files to Evaluation GDB
WBDout=os.path.join(EDHmain, 'QC3_'+ "WBD")
arcpy.CopyFeatures_management('WBD',WBDout)
arcpy.AddMessage('WBD output with Density Increase Attribute(DensIncr) is copied from Temp to Main GDB')

# Calculate Number of Features
count=arcpy.GetCount_management(WBDout)
arcpy.AddMessage('Calculated Number of Features for Report')

# Add Results to Report
reportWksp=os.path.join(EDHwksp, 'EDH_QC_Assessment_TempDir/Report')
with open(reportWksp+'/Report.txt','a') as fout:
    fout.write('Results for QC3 Make Density by HU12\n\n')
    now = datetime.datetime.now()
    currentTime = now.strftime("%B:%d:%Y:%H:%M:%S")
    fout.write('Report Created: {}\n'.format(currentTime))
    fout.write('{}    Created with {} features\n\n\n\n'.format(os.path.basename(WBDout),count))
arcpy.AddMessage('Report Updated')
os.startfile(reportWksp+'/Report.txt')
