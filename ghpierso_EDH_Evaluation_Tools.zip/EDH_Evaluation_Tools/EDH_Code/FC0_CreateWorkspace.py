#Script Name:                   FC0_CreateWorkSpace.py
#Corresponding Script Tool:     FC0 Create Workspace
#Purpose:                       To create geodatabase and temporary workspace for EDH FC Evaluation Tools
#Methodology:                   Copies user EDH Lines, NHD Lines, and DPA file to a geodatabase in the user's input parent folder (EDH_Evaluation.gdb).
#                               Projects all information to the same projection as the input EDH lines.
#                               Creates "EDH_Assessment_TempDir" folder to store temporary analysis datasets.
#Author:                        Gardner Pierson, North Carolina State University, 03/25/2021

#import modules
import sys,os,arcpy

#get arguments
theWS = sys.argv[1]

# Create the main workspace GDB
evalGdb = os.path.join(theWS, "EDH_FC_Evaluation.gdb")
try: 
    arcpy.CreateFileGDB_management(theWS, "EDH_FC_Evaluation.gdb")
except:
    message = 'The "EDH_FC_Evaluation" Geodatabase may already exsist. If so you may need to rename it or move it out of the workspace.'
    print(message)
    arcpy.AddMessage(message)

# Create Temp GDBs
tempDir = os.path.join(theWS, "EDH_FC_Assessment_TempDir")
try:
    os.mkdir(tempDir)
    arcpy.CreateFileGDB_management(tempDir, "tempFC1.gdb")
    arcpy.management.CreateFolder(tempDir,'Report')
    with open(tempDir+'/Report/Report.txt', 'w') as report:
        arcpy.AddMessage('Blank Report Created')
except:
    message2 = 'Either the "EDH_FC_Assessment_TempDir" or one of its Temporary GDBs may already exsist. If so you may need to rename it \
or move it out of the workspace.' 
    print(message2)
    arcpy.AddError(message2)
    
arcpy.AddMessage('Workspace Sucessfully Created')    




