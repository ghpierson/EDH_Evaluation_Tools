#Script Name:                   QC0_CreateWorkspace.py
#Corresponding Script Tool:     QC0 Create Workspace
#Purpose:                       To create geodatabase and temporary workspace for EDH QC Evaluation Tools
#Methodology:                   Copies user EDH Lines, NHD Lines, and DPA file to a geodatabase in the user's input parent folder (EDH_Evaluation.gdb).
#                               Projects all information to the same projection as the input EDH lines.
#                               Creates "EDH_Assessment_TempDir" folder to store temporary analysis datasets.
#Author:                        Gardner Pierson, North Carolina State University, 03/25/2021

#import modules
import sys,os,arcpy

#get arguments
theWS = sys.argv[1]
myEDH_Lines = sys.argv[2]
myEDH_Polygons = sys.argv[3]

# Create the main workspace GDB
evalGdb = os.path.join(theWS, "EDH_QC_Evaluation.gdb")
try: 
    arcpy.CreateFileGDB_management(theWS, "EDH_QC_Evaluation.gdb")
except:
    message = 'The "EDH_QC_Evaluation" Geodatabase may already exsist. If so you may need to rename it or move it out of the workspace.'
    print(message)
    arcpy.AddMessage(message)

# Create Temp GDBs
tempDir = os.path.join(theWS, "EDH_QC_Assessment_TempDir")
try:
    os.mkdir(tempDir)
    arcpy.CreateFileGDB_management(tempDir, "tempQC1.gdb")
    arcpy.CreateFileGDB_management(tempDir, "tempQC2.gdb")
    arcpy.CreateFileGDB_management(tempDir, "tempQC3.gdb")
    arcpy.CreateFileGDB_management(tempDir, "tempQC4.gdb")
    arcpy.CreateFileGDB_management(tempDir, "tempQC5.gdb")
    arcpy.CreateFileGDB_management(tempDir, "tempQC6.gdb")
    arcpy.management.CreateFolder(tempDir,'Report')
    with open(tempDir+'/Report/Report.txt', 'w') as report:
        arcpy.AddMessage('Blank Report Created')
except:
    message2 = 'Either the "EDH_QC_Assessment_TempDir" or one of its Temporary GDBs may already exsist. If so you may need to rename it \
or move it out of the workspace.' 
    print(message2)
    arcpy.AddMessage(message2)
    
# Copy input data into new EDH evaluation gdb

EDH_Lines = os.path.join(evalGdb, "EDH_Lines")
EDH_Polygons = os.path.join(evalGdb, "EDH_Polygons")
try:
    arcpy.CopyFeatures_management(myEDH_Lines, EDH_Lines)
    arcpy.CopyFeatures_management(myEDH_Polygons, EDH_Polygons)
except:
    print 'The Line and Polygon FCs may already exsist in the GDB'
    arcpy.AddMessage('The Line and Polygon FCs may already exsist in the GDB')

# Create Cursor to check if There are Null Values in your EDH data FCode attribute
try:
    field=['FCode']
    cursor = arcpy.da.SearchCursor(EDH_Lines, field)
    for row in cursor:
        if row[0] == None:
            arcpy.AddError('The EDH Line Data May Have Some Null FCode Values. Please Check Before You Run Addiontal Tools.')
            break
    del cursor
    cursor = arcpy.da.SearchCursor(EDH_Polygons, field)
    for row in cursor:
        if row[0] == None:
            arcpy.AddError('The EDH Polygon Data May Have Some Null FCode Values. Please Check Before You Run Addiontal Tools.')
            break
    del cursor
except:
    arcpy.AddMessage('Unable to Check EDH Data for Null FCodes, Please Verify Data has a valid "FCode" field Before Running Addiontal Tools')
    del cursor 
                       
    




